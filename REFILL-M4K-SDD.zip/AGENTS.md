# LootRefill — Agent Development Rules

## Purpose

LootRefill uses a lightweight Spec-Driven Development (SDD) workflow.

Before modifying code, the agent MUST read:

1. `SDD/PROJECT_SPEC.md`
2. `SDD/INVARIANTS.md`
3. `SDD/ARCHITECTURE.md`
4. The specification for the current stage, when one exists.

## Source of Truth

The current codebase and SDD documents are the source of truth.

Historical stage documents are references to previous work. They must not automatically override the current SDD.

If there is a conflict:
1. Inspect the current code.
2. Respect `SDD/INVARIANTS.md`.
3. Respect `SDD/PROJECT_SPEC.md`.
4. Respect the current stage specification.

If it cannot be resolved safely, report the conflict instead of guessing.

## Before Coding

Before implementation:
1. Read the relevant SDD documents.
2. Inspect the existing implementation.
3. Identify affected modules.
4. Identify invariants that could be affected.
5. Reuse existing systems when possible.
6. Avoid unnecessary architectural changes.

For significant changes, briefly state what will change, affected files/modules, and what must remain untouched.

## Preserve Existing Systems

Do not silently replace or remove:
- Container identity/protection.
- MAP / PLAYER / BROKEN / DISABLED handling.
- SQLite persistence.
- Legacy LootTable support.
- LootPool support.
- PopulateQueue.
- RefillQueue.
- Round-robin processing.
- Chunk loading/unloading controls.
- `require-empty`.
- Config-driven refill intervals.
- Region selection/scanning.
- Existing GUI protections.
- Existing commands.

If an existing system must change, explain why and update the appropriate SDD.

## Thread Safety

Bukkit/Paper operations involving worlds, blocks, inventories, entities and other thread-sensitive APIs must run on the appropriate server thread.

Database operations and CPU-only calculations may be asynchronous when safe.

Never modify Bukkit inventories asynchronously.

## Performance

Respect configured limits such as:
- `containers-per-tick`
- `max-ms-per-tick`
- `batch-delay-ticks`
- `max-refills-per-cycle`
- chunk limits

Avoid unbounded queues, large synchronous loops, unnecessary full-world scans and unnecessary chunk loading.

## Container Protection

PLAYER containers must never be modified automatically unless an explicit administrative action intentionally converts them to MAP.

BROKEN, DISABLED and UNKNOWN containers must not be automatically populated or refilled.

Never assume every physical container belongs to LootRefill.

## Inventory Safety

When `require-empty: true` and a container contains items, return:

```text
SKIPPED_NOT_EMPTY
```

Never clear or overwrite existing contents.

A skipped container must not block other queue work.

## Loot System

A container can use:
- `loot_pool_id`
- legacy `loot_table_id`

Priority:

```text
LootPool
  ↓
Legacy LootTable
```

Legacy LootTable compatibility must remain.

## Loot Pools

Supported modes:
- `SINGLE_RANDOM`
- `MIXED_RANDOM`

Default:

```text
allow_duplicates = false
```

When false, MIXED_RANDOM selects without replacement.

Invalid pools must fail safely.

## Refill Intervals

The active `config.yml` is the source of truth for refill intervals.

The historical database field `refill_interval_seconds` must not override current configuration.

Scheduling:

```text
next_refill = current_time + configured_interval
```

Persist the result to SQLite.

## Persistence

SQLite is the persistent storage layer.

Migrations must preserve existing information whenever reasonably possible.

Do not delete/reset data without explicit instruction.

## GUI

Administrative GUIs must:
- Require appropriate permission.
- Prevent unintended item theft/duplication.
- Prevent unintended drag/shift-click interactions.
- Use reliable GUI identification.
- Avoid unnecessary chunk/inventory loading.

## Commands

Existing commands remain compatible unless explicitly changed.

Validate arguments, permissions, worlds, containers, tables, pools and numeric values.

## Testing

After implementation:
1. Run relevant automated tests.
2. Run `mvn clean package`.
3. Confirm `BUILD SUCCESS`.
4. Provide runtime test steps when applicable.
5. Do not claim runtime validation if only compilation was performed.

## Documentation

For each new stage:
- Create/update its SDD specification.
- Document new invariants if introduced.
- Document important architectural decisions.
- Keep documentation concise.

## Change Discipline

Prefer the smallest safe change.

Do not refactor unrelated code, rewrite working subsystems, or change database/config semantics without reason.

## Completion Report

Report:
- Files created/modified.
- Behavior changed.
- Compatibility preserved.
- Tests performed.
- Build result.
- Known limitations.

## Golden Rule

Optimize for:

```text
Correctness
+
Compatibility
+
Performance
+
Maintainability
```

New features must integrate with existing systems instead of creating unnecessary parallel implementations.
